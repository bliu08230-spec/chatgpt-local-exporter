(() => {
  "use strict";
  const Core = globalThis.ChatExportCore;
  const Convert = globalThis.ChatExportConvert;
  const Single = globalThis.ChatExportSingle;
  const Word = globalThis.ChatExportWord;
  const Batch = globalThis.ChatExportBatch;
  const $ = id => document.getElementById(id);
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const CHAT_PATTERN = /^https:\/\/(chatgpt\.com|chat\.openai\.com)\//;
  const FORMAT_HINTS = {
    docx: "真正的 .docx 文件，问题、图片与回答按顺序保存；图片嵌入后可离线查看，长对话自动分卷。",
    md: "适合 Obsidian、Typora 等 Markdown 编辑器。",
    html: "双击即可离线阅读，远程图片以链接保留。",
    json: "保留消息角色、ID、正文及扫描报告，便于二次处理。",
    txt: "通用纯文本，适合快速阅读与检索。",
    zip: "包含 Markdown / HTML / JSON / TXT 与扫描报告；含图片的 Word 请单独选择导出。"
  };
  const ROLE_LABEL = { user: "用户", assistant: "ChatGPT", system: "系统", tool: "工具", function: "工具" };
  const LIST_PAGE = 40;

  const state = {
    tabId: Number(new URLSearchParams(location.search).get("tabId")) || 0,
    tab: null,
    single: { data: null, busy: false, saving: false, job: null, cancel: false, imageJob: null },
    all: {
      items: [], selected: new Set(), rows: new Map(), shown: LIST_PAGE,
      account: null, loading: false, running: false, signal: null, failures: [],
      folder: null, zipFiles: null, previous: null
    }
  };

  /* ---------------------------------------------------------------- helpers */
  function setStatus(element, text, stateName) {
    const box = $(element);
    if (box) box.dataset.state = stateName || "idle";
    const label = element === "status-box" ? $("status") : $("account-text");
    if (label) label.textContent = text;
  }
  function batchStatus(text, stateName) {
    $("batch-status").dataset.state = stateName || "idle";
    $("batch-text").textContent = text;
  }
  function logLine(text, kind) {
    const node = document.createElement("div");
    node.className = kind || "ok";
    node.textContent = text;
    $("log").append(node);
    $("log").hidden = false;
    $("log").scrollTop = $("log").scrollHeight;
    while ($("log").childElementCount > 400) $("log").removeChild($("log").firstElementChild);
  }
  function friendly(error) {
    const text = (error && error.message) || String(error);
    if (/Receiving end does not exist|Could not establish connection|message channel closed|message port closed|The message port closed/i.test(text)) return "无法连接 ChatGPT 页面。请确认该标签页仍打开着 chatgpt.com，刷新后再试。";
    if (/No tab with id|tab was closed|Invalid tab ID/i.test(text)) return "ChatGPT 标签页已关闭，请重新打开对话后点击扩展图标。";
    if (/Cannot access contents|Cannot access a chrome|Missing host permission/i.test(text)) return "没有 chatgpt.com 的访问权限，请在扩展详情页检查站点访问权限。";
    if (/AbortError/i.test(text)) return "操作已取消。";
    return text;
  }
  function epochIso(value) {
    if (value == null || value === "") return null;
    if (typeof value === "string") {
      const parsed = new Date(value);
      return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
    }
    const number = Number(value);
    if (!Number.isFinite(number) || number <= 0) return null;
    return new Date(number * 1000).toISOString();
  }
  function clock(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value).slice(0, 16);
    return date.toISOString().replace("T", " ").slice(0, 16);
  }
  function send(tabId, message, timeout) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("ChatGPT 页面响应超时，请刷新该标签页后重试")), timeout || 150000);
      chrome.tabs.sendMessage(tabId, message).then(value => { clearTimeout(timer); resolve(value); }, error => { clearTimeout(timer); reject(error); });
    });
  }
  const injectedTabs = new Set();
  async function injectApi(tabId) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content/api.js"] });
    injectedTabs.add(tabId);
  }
  function isDetached(error) {
    return /Receiving end does not exist|Could not establish connection|message channel closed|message port closed|The message port closed/i.test(String((error && error.message) || error));
  }
  async function api(tabId, message, timeout) {
    const payload = Object.assign({ type: "archive-api" }, message);
    if (!injectedTabs.has(tabId)) await injectApi(tabId);
    let result;
    try {
      result = await send(tabId, payload, timeout);
    } catch (error) {
      if (!isDetached(error)) throw error;
      // The page reloaded (or the tab was replaced) and lost the script.
      await injectApi(tabId);
      result = await send(tabId, payload, timeout);
    }
    if (!result) throw new Error("页面没有返回数据，请刷新 ChatGPT 标签页后重试");
    if (!result.ok) throw new Error(result.error || "页面返回失败");
    return result.data;
  }
  async function isChatTab(tab) {
    if (!tab || !tab.id) return false;
    if (!CHAT_PATTERN.test(tab.url || "")) return false;
    try { await chrome.tabs.get(tab.id); return true; } catch { return false; }
  }
  async function resolveTab() {
    if (state.tabId) {
      let tab = null;
      try { tab = await chrome.tabs.get(state.tabId); } catch { tab = null; }
      if (await isChatTab(tab)) return tab;
    }
    const tabs = await chrome.tabs.query({ url: ["https://chatgpt.com/*", "https://chat.openai.com/*"] });
    const list = tabs.filter(tab => tab && tab.id);
    list.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
    for (const tab of list) if (await isChatTab(tab)) { state.tabId = tab.id; return tab; }
    return null;
  }
  async function ensureTab() {
    const tab = await resolveTab();
    if (tab) return tab;
    const created = await chrome.tabs.create({ url: "https://chatgpt.com/", active: true });
    for (let index = 0; index < 80; index += 1) {
      await sleep(500);
      let current = null;
      try { current = await chrome.tabs.get(created.id); } catch { break; }
      if (current && CHAT_PATTERN.test(current.url || "") && current.status === "complete") return current;
    }
    throw new Error("没有找到 ChatGPT 标签页。请先打开 https://chatgpt.com/ 并登录后再试。");
  }

  /* --------------------------------------------------------------- tabs UI */
  function activateTab(view) {
    for (const name of ["single", "all"]) {
      const isActive = name === view;
      $("tab-" + name).classList.toggle("is-active", isActive);
      $("tab-" + name).setAttribute("aria-selected", String(isActive));
      $("view-" + name).hidden = !isActive;
    }
    if (view === "all") refreshAccount(false).catch(() => {});
  }

  /* ================================================================ single */
  function updateSingle() {
    const { data, busy, saving } = state.single;
    $("scan").disabled = busy || saving || !state.tab;
    $("scan").textContent = data ? "重新读取当前对话" : "读取当前对话";
    $("save-folder").disabled = $("save-file").disabled = !data || busy || saving;
    $("cancel").hidden = !busy && !(saving && $("format").value === "docx");
    $("auto").disabled = $("limit").disabled = busy || saving;
    $("read-mode").disabled = busy || saving;
    $("word-options").hidden = $("format").value !== "docx";
    $("word-images").disabled = busy || saving;
    $("format").disabled = busy || saving;
    $("progress").hidden = !busy && !saving;
    $("format-hint").textContent = FORMAT_HINTS[$("format").value] || "";
    if (typeof window.showDirectoryPicker !== "function") {
      $("save-folder").hidden = true;
      $("save-file").textContent = "选择位置并保存文件…";
    }
  }
  function showPreview() {
    const data = state.single.data;
    $("empty").hidden = true;
    $("preview").hidden = false;
    $("preview").replaceChildren();
    $("count").textContent = data.messages.length + " 条消息";
    data.messages.slice(0, 6).forEach((message, index) => {
      const item = document.createElement("article");
      item.className = "message";
      const label = document.createElement("div");
      label.className = "message-label";
      label.textContent = String(index + 1).padStart(2, "0") + "  " + (ROLE_LABEL[message.role] || message.role);
      const text = document.createElement("p");
      text.textContent = message.text.slice(0, 1400) + (message.text.length > 1400 ? "\n…" : "");
      item.append(label, text);
      $("preview").append(item);
    });
    if (data.messages.length > 6) {
      const more = document.createElement("p");
      more.className = "more";
      more.textContent = "此处只预览前 6 条；保存文件包含本次读取的全部 " + data.messages.length + " 条。";
      $("preview").append(more);
    }
    $("report").hidden = false;
    $("scan-meta").textContent = data.scan.method === "conversation-api"
      ? "读取来源：当前会话数据 · 耗时 " + (data.scan.duration_ms / 1000).toFixed(1) + " 秒 · 不受网页扫描等待上限影响"
      : "读取来源：网页扫描 · 耗时 " + (data.scan.duration_ms / 1000).toFixed(1) + " 秒 · " + data.scan.steps + " 次扫描 · 顶部 " + (data.scan.reached_top ? "已到达" : "未确认") + " · 底部 " + (data.scan.reached_bottom ? "已到达" : "未确认");
    $("warnings").replaceChildren(...data.scan.warnings.map(value => { const li = document.createElement("li"); li.textContent = value; return li; }));
    $("source-title").textContent = data.title;
  }
  async function scanSingle() {
    const single = state.single;
    if (single.busy || !state.tab) return;
    single.busy = true;
    single.data = null;
    single.cancel = false;
    single.job = "single-" + Date.now().toString(36);
    updateSingle();
    $("preview").hidden = $("report").hidden = true;
    $("empty").hidden = false;
    $("count").textContent = "0 条消息";
    $("media-status").hidden = true;
    setStatus("status-box", "正在连接 ChatGPT 页面…", "idle");
    try {
      const tab = await chrome.tabs.get(state.tab.id);
      if (!CHAT_PATTERN.test(tab.url || "")) throw new Error("原标签页已离开 ChatGPT，请打开具体对话后重新点击扩展图标。");
      const started = performance.now();
      let apiFailure = null;
      const conversationId = Single.conversationId(tab.url);
      if ($("read-mode").value === "auto" && $("auto").checked && conversationId) {
        setStatus("status-box", "正在读取当前会话数据，无需向上翻页…", "idle");
        try {
          const conversation = await fetchConversation(tab.id, conversationId, () => single.cancel);
          if (single.cancel) throw new Error("已取消扫描，未保存文件。");
          const currentTab = await chrome.tabs.get(tab.id);
          if (Single.conversationId(currentTab.url) !== conversationId) throw new Error("读取期间切换了对话，请重新读取。");
          single.data = Single.fromConversation(conversation, tab.url, performance.now() - started);
        } catch (error) {
          if (single.cancel) throw error;
          apiFailure = friendly(error);
        }
      }
      if (single.data) {
        showPreview();
        setStatus("status-box", "已从当前会话数据读取 " + single.data.messages.length + " 条消息，可以保存到本地。", "success");
        return;
      }
      const fallbackTab = await chrome.tabs.get(tab.id);
      if (fallbackTab.url !== tab.url) throw new Error("读取期间切换了对话，请重新读取。");
      if (apiFailure) setStatus("status-box", "会话数据暂不可用，正在尝试网页兼容扫描…", "idle");
      await chrome.scripting.executeScript({ target: { tabId: state.tab.id }, files: ["lib/core.js", "content/collector.js"] });
      if (single.cancel) throw new Error("已取消扫描，未保存文件。");
      const waitLimit = Number($("limit").value);
      const result = await send(state.tab.id, { type: "collect-conversation", job: single.job, options: { autoLoad: $("auto").checked, maxMs: waitLimit } }, waitLimit > 0 ? waitLimit + 20000 : 24 * 60 * 60 * 1000);
      if (single.cancel) throw new Error("已取消扫描，未保存文件。");
      if (!result || !result.ok) throw new Error(((result && result.error) || "没有获取到扫描结果。") + (apiFailure ? " 会话数据读取也未成功：" + apiFailure : ""));
      single.data = result.data;
      if (apiFailure) single.data.scan.warnings.push("会话数据读取失败后改用网页扫描：" + apiFailure);
      showPreview();
      setStatus("status-box", "已读取 " + single.data.messages.length + " 条消息，可以保存到本地。" + (single.data.scan.timed_out ? " 本次达到时限，请查看扫描报告。" : ""), single.data.scan.timed_out ? "warning" : "success");
    } catch (error) {
      setStatus("status-box", friendly(error), "error");
    } finally {
      single.busy = false;
      updateSingle();
    }
  }
  function singleOutput() {
    const data = state.single.data;
    const format = $("format").value;
    const files = Core.files(data, format);
    const stamp = data.exported_at.slice(0, 19).replace(/[T:]/g, "-");
    if (format === "zip") return { name: Core.safeFilename(data.title) + "_" + stamp + ".zip", blob: Core.zip(files), size: null };
    const file = files[0];
    return { name: file.name, blob: new Blob([file.content], { type: file.type }) };
  }
  async function fetchConversation(tabId, id, cancelled) {
    const data = await api(tabId, { action: "conversation", id }, 180000);
    if (!data?.chunked) {
      if (cancelled?.()) throw new Error("已取消扫描，未保存文件。");
      return data?.conversation;
    }
    try {
      let text = "";
      for (let index = 0; index < data.parts; index++) {
        if (cancelled?.()) throw new Error("已取消扫描，未保存文件。");
        const part = await api(tabId, { action: "part", job: data.job, index }, 60000);
        text += part.part;
      }
      return JSON.parse(text).conversation;
    } finally { await send(tabId, { type: "archive-api", action: "release", job: data.job }).catch(() => {}); }
  }
  async function downloadBlob(blob, name, saveAs) {
    const url = URL.createObjectURL(blob);
    try {
      const id = await chrome.downloads.download({ url, filename: name, saveAs: Boolean(saveAs), conflictAction: "uniquify" });
      const until = Date.now() + 120000;
      while (Date.now() < until) {
        const [entry] = await chrome.downloads.search({ id });
        if (entry && entry.state === "complete") return entry;
        if (entry && entry.state === "interrupted") throw new Error("下载被中断：" + (entry.error || "请重试"));
        await sleep(350);
      }
      throw new Error("下载尚未完成，请打开浏览器下载列表查看。");
    } finally {
      URL.revokeObjectURL(url);
    }
  }
  async function uniqueFile(directory, name) {
    const dot = name.lastIndexOf(".");
    for (let index = 0; index < 1000; index += 1) {
      const candidate = index === 0 ? name : name.slice(0, dot) + " (" + index + ")" + name.slice(dot);
      try {
        await directory.getFileHandle(candidate);
      } catch (error) {
        if (error.name !== "NotFoundError") throw error;
        return { handle: await directory.getFileHandle(candidate, { create: true }), name: candidate };
      }
    }
    throw new Error("同名文件过多，请换一个文件夹。");
  }
  async function saveSingle(mode) {
    const single = state.single;
    if (!single.data || single.busy || single.saving) return;
    single.saving = true;
    single.cancel = false;
    updateSingle();
    try {
      const pending = mode === "folder" && typeof window.showDirectoryPicker === "function"
        ? window.showDirectoryPicker({ id: "chatgpt-local-exporter", mode: "readwrite", startIn: "downloads" })
        : null;
      const directory = pending ? await pending : null;
      setStatus("status-box", "正在生成并保存文件…", "idle");
      if ($("format").value === "docx") {
        await saveWord(directory);
        return;
      }
      const item = singleOutput();
      if (directory) {
        const written = await uniqueFile(directory, item.name);
        const writable = await written.handle.createWritable();
        try { await writable.write(item.blob); await writable.close(); }
        catch (error) { try { await writable.abort(); } catch { /* ignore */ } throw error; }
        setStatus("status-box", "已保存：" + written.name + "（" + single.data.messages.length + " 条消息）", "success");
      } else {
        const entry = await downloadBlob(item.blob, item.name, true);
        setStatus("status-box", "已保存：" + (entry.filename || item.name) + "（" + single.data.messages.length + " 条消息）", "success");
      }
    } catch (error) {
      if (error.name === "AbortError") setStatus("status-box", "已取消保存，扫描结果仍保留。", "idle");
      else if (single.cancel) setStatus("status-box", "已取消Word导出，已经保存的分卷会保留。扫描结果仍可重新导出。", "warning");
      else setStatus("status-box", "保存失败：" + friendly(error), "error");
    } finally {
      single.saving = false;
      updateSingle();
    }
  }

  /* ---------------------------------------------------- Word: independent export path */
  async function imageRequest(tabId, message) {
    const response = await send(tabId, Object.assign({ type: "archive-image" }, message), 60000);
    if (!response?.ok) throw new Error(response?.error || "图片读取失败");
    return response.data;
  }
  async function fetchCdnImage(url) {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" || !parsed.hostname.endsWith(".oaiusercontent.com")) throw new Error("不支持的图片下载域名");
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 45000);
    state.single.imageController = controller;
    try {
      const response = await fetch(parsed.href, { credentials: "omit", signal: controller.signal });
      if (!response.ok) throw new Error("图片HTTP " + response.status);
      const max = 32 * 1024 * 1024;
      if (Number(response.headers.get("content-length")) > max) throw new Error("单图超过32MB");
      const reader = response.body.getReader(), chunks = [];
      let size = 0;
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          size += value.length;
          if (size > max) throw new Error("单图超过32MB");
          chunks.push(value);
        }
      } catch (error) { await reader.cancel().catch(() => {}); throw error; }
      const bytes = new Uint8Array(size);
      let offset = 0;
      for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
      return { bytes, mime: response.headers.get("content-type") };
    } finally { clearTimeout(timer); state.single.imageController = null; }
  }
  async function loadWordImage(tabId, asset, message, index, count) {
    const single = state.single;
    if (single.cancel) throw new Error("已取消Word导出");
    if ((await chrome.tabs.get(tabId)).url !== single.data.source_url) throw new Error("原对话已切换，未读取其他聊天的图片");
    const job = "image-" + crypto.randomUUID();
    single.imageJob = job;
    try {
      let info = await imageRequest(tabId, { action: "start", job, asset, messageId: message.message_id, index, count });
      if (single.cancel) throw new Error("已取消Word导出");
      let data;
      if (info.retry_url) {
        try { data = await fetchCdnImage(info.retry_url); }
        catch (error) {
          if (single.cancel) throw error;
          info = await imageRequest(tabId, { action: "start", job, asset, messageId: message.message_id, index, count, previewOnly: true });
          if (info.retry_url) data = await fetchCdnImage(info.retry_url);
        }
      }
      if (!data) {
        const bytes = new Uint8Array(info.size);
        let offset = 0;
        for (let part = 0; part < info.parts; part++) {
          if (single.cancel) throw new Error("已取消Word导出");
          const chunk = await imageRequest(tabId, { action: "part", job, index: part });
          const raw = atob(chunk.base64);
          for (let i = 0; i < raw.length; i++) bytes[offset++] = raw.charCodeAt(i);
        }
        if (offset !== bytes.length) throw new Error("图片分片长度不一致");
        data = { bytes, mime: info.mime };
      }
      const decoded = await Word.decodeImage(data.bytes, data.mime, asset.name || asset.alt);
      decoded.preview = Boolean(info.preview);
      return decoded;
    } finally {
      single.imageJob = null;
      await send(tabId, { type: "archive-image", action: "release", job }).catch(() => {});
    }
  }
  async function saveWord(directory) {
    const single = state.single, data = single.data, embed = $("word-images").checked;
    const tabId = state.tab.id;
    // Text export uses only the already-read snapshot. Images require the same
    // conversation to remain open; never silently use a different account/tab.
    if (embed && data.messages.some(m => Word.imageAssets(m).length)) {
      const tab = await chrome.tabs.get(tabId);
      if (tab.url !== data.source_url) throw new Error("原对话已切换，请重新读取后再保存含图片的Word。");
      await chrome.scripting.executeScript({ target: { tabId }, files: ["content/images.js"] });
    }
    const stamp = data.exported_at.slice(0, 19).replace(/[T:]/g, "-");
    const base = Core.safeFilename(data.title) + "_" + stamp;
    let saved = 0;
    async function output(name, blob) {
      if (single.cancel) throw new Error("已取消Word导出");
      if (directory) {
        const file = await uniqueFile(directory, name);
        const writable = await file.handle.createWritable();
        try { await writable.write(blob); await writable.close(); }
        catch (error) { try { await writable.abort(); } catch {} throw error; }
      } else await downloadBlob(blob, name, true);
    }
    // Do not attach downloaded bytes to state.single.data or extension storage.
    // Volumes are written and released one at a time.
    const wordData = embed ? data : { ...data, messages: data.messages.map(m => ({ ...m, images: [], attachments: [], content_parts: null })) };
    $("media-status").hidden = false;
    $("media-status").textContent = "正在准备Word；关闭本导出页会中断任务。";
    const report = await Word.exportVolumes(wordData, {
      cancelled: () => single.cancel,
      loadImage: (asset, message, index, count) => loadWordImage(tabId, asset, message, index, count),
      onProgress: progress => {
        $("media-status").textContent = "正在处理消息 " + progress.message + "/" + progress.total + " · 图片成功 " + progress.images.success + " · 失败 " + progress.images.failed;
      },
      onVolume: async (blob, volume) => {
        setStatus("status-box", "正在保存Word第 " + volume.number + " 卷（消息 " + volume.first + "—" + volume.last + "）…", "idle");
        await output(base + "_" + String(volume.number).padStart(3, "0") + ".docx", blob); saved++;
      }
    });
    report.source_url = data.source_url;
    report.embedded_images = embed;
    report.exported_at = new Date().toISOString();
    await output(base + "_Word导出报告.json", new Blob([JSON.stringify(report, null, 2)], { type: "application/json" }));
    $("media-status").textContent = "Word共 " + saved + " 卷 · 图片成功 " + report.images.success + "（网页预览 " + report.images.previews + "）· 失败 " + report.images.failed + "；详细结果见Word导出报告。";
    setStatus("status-box", "已保存：" + saved + " 个Word文件（" + data.messages.length + " 条消息）" + (report.images.failed ? "；部分图片未获取，已在对应位置标记。" : "。"), report.images.failed ? "warning" : "success");
  }

  /* =================================================================== all */
  async function refreshAccount(notify) {
    const all = state.all;
    if (all.running) return;
    try {
      const tab = await ensureTab();
      state.tab = tab;
      state.tabId = tab.id;
      const info = await api(tab.id, { action: "status" }, 40000);
      all.account = info;
      if (!info.logged_in) {
        setStatus("account-status", "未检测到登录状态。请在该标签页登录 ChatGPT 后点「刷新登录状态」。", "warning");
        return;
      }
      const plan = info.plan ? " · " + info.plan : "";
      setStatus("account-status", "已连接：" + (info.user?.name || info.user?.email || "当前账号") + plan, "success");
      if (notify) batchStatus("登录状态已刷新。", "success");
    } catch (error) {
      setStatus("account-status", friendly(error), "error");
    }
  }
  async function scanAccount() {
    const all = state.all;
    if (all.loading || all.running) return;
    all.loading = true;
    $("scan-all").disabled = true;
    $("export-folder").disabled = $("export-zip").disabled = true;
    batchStatus("正在读取账号对话列表…", "idle");
    $("bar").hidden = false;
    $("bar").value = 3;
    try {
      const tab = await ensureTab();
      state.tab = tab;
      state.tabId = tab.id;
      const [main, archived] = await Promise.all([
        api(tab.id, { action: "list", archived: false }, 24 * 60 * 60 * 1000),
        $("opt-archived").checked ? api(tab.id, { action: "list", archived: true }, 24 * 60 * 60 * 1000).catch(error => ({ items: [], error: String(error.message || error) })) : Promise.resolve({ items: [] })
      ]);
      const merged = new Map();
      for (const item of main.items || []) merged.set(item.id, item);
      for (const item of archived.items || []) if (!merged.has(item.id)) merged.set(item.id, item);
      let items = Array.from(merged.values()).sort((a, b) => (b.update_time || 0) - (a.update_time || 0));
      const limit = Number($("limit-all").value) || 0;
      const total = items.length;
      if (limit > 0 && items.length > limit) items = items.slice(0, limit);
      all.items = items;
      all.selected = new Set(items.map(item => item.id));
      all.shown = LIST_PAGE;
      all.rows = new Map();
      all.failures = [];
      $("list-card").hidden = false;
      $("list-count").textContent = items.length + (items.length !== total ? " / " + total : "") + " 条";
      $("list-meta").textContent = items.length ? "最早更新 " + clock(epochIso(items[items.length - 1].update_time)) + " · 最新 " + clock(epochIso(items[0].update_time)) : "";
      renderList();
      const hasSelection = items.length > 0;
      $("export-folder").disabled = !hasSelection;
      $("export-zip").disabled = !hasSelection;
      $("bar").value = 100;
      batchStatus(items.length ? "已读取 " + items.length + " 条对话，选择后点「选择文件夹并导出」。" : "账号下没有读到对话。", items.length ? "success" : "warning");
      if (archived.error) batchStatus("已读取 " + items.length + " 条普通对话，但归档列表读取失败：" + archived.error, "warning");
    } catch (error) {
      batchStatus(friendly(error), "error");
    } finally {
      all.loading = false;
      $("scan-all").disabled = false;
      $("scan-all").textContent = "重新读取对话列表";
      $("bar").hidden = true;
    }
  }
  function renderList() {
    const all = state.all;
    const container = $("conv-list");
    container.replaceChildren();
    const slice = all.items.slice(0, all.shown);
    for (const item of slice) {
      const li = document.createElement("li");
      li.className = "conv";
      const label = document.createElement("label");
      const box = document.createElement("input");
      box.type = "checkbox";
      box.checked = all.selected.has(item.id);
      box.dataset.id = item.id;
      box.addEventListener("change", () => {
        if (box.checked) all.selected.add(item.id); else all.selected.delete(item.id);
        $("list-count").textContent = all.selected.size + " / " + all.items.length + " 条选中";
        $("export-folder").disabled = $("export-zip").disabled = all.selected.size === 0 || all.running;
      });
      const title = document.createElement("span");
      title.className = "conv-title";
      title.textContent = item.title;
      title.title = item.title;
      const meta = document.createElement("span");
      meta.className = "conv-meta";
      meta.textContent = (item.archived ? "已归档 · " : "") + clock(epochIso(item.update_time || item.create_time));
      label.append(box, title, meta);
      li.append(label);
      container.append(li);
    }
    $("show-more").hidden = all.shown >= all.items.length;
    $("list-count").textContent = all.selected.size === 0 ? "0 / " + all.items.length + " 条选中" : all.selected.size + " / " + all.items.length + " 条选中";
  }
  function bindListControls() {
    $("select-all").addEventListener("click", () => {
      state.all.selected = new Set(state.all.items.map(item => item.id));
      renderList();
      $("export-folder").disabled = $("export-zip").disabled = state.all.running;
    });
    $("select-none").addEventListener("click", () => {
      state.all.selected.clear();
      renderList();
      $("export-folder").disabled = $("export-zip").disabled = true;
    });
    $("show-more").addEventListener("click", () => {
      state.all.shown += LIST_PAGE;
      renderList();
    });
  }

  /* ---------------------------------------------------------- folder utils */
  async function readManifest(directory) {
    try {
      const handle = await directory.getFileHandle("manifest.json");
      const file = await handle.getFile();
      return JSON.parse(await file.text());
    } catch (error) {
      if (error.name === "NotFoundError") return null;
      throw new Error("无法读取已有 manifest.json，请换一个空文件夹或修复存档清单：" + friendly(error));
    }
  }
  async function writeInto(directory, path, content) {
    const parts = path.split("/");
    let current = directory;
    for (const part of parts.slice(0, -1)) current = await current.getDirectoryHandle(part, { create: true });
    const name = parts[parts.length - 1];
    let handle;
    try {
      handle = await current.getFileHandle(name);
    } catch (error) {
      if (error.name !== "NotFoundError") throw error;
      handle = await current.getFileHandle(name, { create: true });
    }
    const writable = await handle.createWritable();
    try {
      await writable.write(typeof content === "string" ? content : new Blob([content]));
      await writable.close();
    } catch (error) {
      try { await writable.abort(); } catch { /* ignore */ }
      throw error;
    }
  }
  function pushZip(all, path, content) {
    all.zipFiles.push({ name: path, content: typeof content === "string" ? content : content });
  }

  /* ----------------------------------------------------------- batch build */
  const EXT = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif", "application/pdf": "pdf", "text/plain": "txt" };
  function extensionOf(asset, mime) {
    const fromMime = EXT[String(mime || asset.mime || "").split(";")[0].trim()];
    if (fromMime) return fromMime;
    const byName = String(asset.name || "").match(/\.([A-Za-z0-9]{1,6})$/);
    return byName ? byName[1].toLowerCase() : "bin";
  }
  function safeName(value, fallback) {
    const cleaned = Core.safeFilename(value || fallback || "file");
    return cleaned || fallback || "file";
  }
  async function saveAssets(tabId, doc, write, all, convDir) {
    const assets = [];
    for (const message of doc.messages) for (const asset of message.assets) if (asset.file_id && !assets.includes(asset)) assets.push(asset);
    let index = 0;
    for (const asset of assets.slice(0, 60)) {
      index += 1;
      try {
        const data = await api(tabId, { action: "download", fileId: asset.file_id }, 90000);
        const raw = atob(data.base64 || "");
        const bytes = new Uint8Array(raw.length);
        for (let position = 0; position < raw.length; position += 1) bytes[position] = raw.charCodeAt(position);
        const name = safeName(asset.name || asset.file_id, "asset") + "." + extensionOf(asset, data.mime);
        const path = convDir + "/" + name;
        await write(path, bytes);
        asset.saved_path = path;
      } catch (error) {
        logLine("附件跳过 " + (asset.file_id || asset.name) + "：" + String(error.message || error), "skip");
      }
    }
  }

  async function exportAll(mode) {
    const all = state.all;
    if (all.running) return;
    const chosen = all.items.filter(item => all.selected.has(item.id));
    if (!chosen.length) { batchStatus("请先勾选要导出的对话。", "warning"); return; }
    let picker = null;
    if (mode === "folder") {
      if (typeof window.showDirectoryPicker !== "function") { batchStatus("当前浏览器不支持选择文件夹，请改用「打包 ZIP 下载」。", "warning"); return; }
      picker = window.showDirectoryPicker({ id: "chatgpt-archive", mode: "readwrite", startIn: "downloads" });
    }
    let directory = null;
    try { directory = picker ? await picker : null; }
    catch (error) {
      if (error.name === "AbortError") { batchStatus("已取消选择文件夹。", "idle"); return; }
      batchStatus("无法使用该文件夹：" + friendly(error), "error");
      return;
    }
    let tab = null;
    try { tab = await ensureTab(); }
    catch (error) { batchStatus(friendly(error), "error"); return; }
    state.tab = tab;
    state.tabId = tab.id;

    all.running = true;
    all.signal = { cancelled: false };
    all.failures = [];
    all.rows = new Map();
    all.zipFiles = mode === "zip" ? [] : null;
    all.folder = directory;
    $("cancel-all").hidden = false;
    $("scan-all").disabled = true;
    $("export-folder").disabled = $("export-zip").disabled = true;
    $("stats").hidden = false;
    $("log").replaceChildren();
    $("log").hidden = false;
    $("bar").hidden = false;
    $("bar").value = 0;
    $("stat-done").textContent = "0 / " + chosen.length;
    $("stat-written").textContent = "0";
    $("stat-skipped").textContent = "0";
    $("stat-failed").textContent = "0";
    batchStatus("准备导出 " + chosen.length + " 条对话…", "idle");
    const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);

    const write = async (path, content) => {
      if (directory) await writeInto(directory, path, content);
      else pushZip(all, path, content);
    };

    let written = 0, skipped = 0;
    const pendingRows = new Map();
    try {
      all.previous = null;
      if (directory && $("opt-incremental").checked) {
        all.previous = await readManifest(directory);
        if (all.previous && (all.previous.platform !== "ChatGPT" || !all.previous.conversations || typeof all.previous.conversations !== "object")) throw new Error("目标文件夹的 manifest.json 不是有效的 ChatGPT 存档，请选择空文件夹。");
        const owner = all.account?.user?.email || all.account?.user?.name || "";
        if (all.previous?.owner && owner && all.previous.owner !== owner) throw new Error("该文件夹属于另一个账号，请为当前账号选择独立文件夹。");
        if (all.previous) batchStatus("已读取旧 manifest.json，将检查并跳过未变化的对话。", "idle");
      }
      const result = await Batch.run({
        items: chosen,
        signal: all.signal,
        concurrency: 2,
        retries: 2,
        delay: 220,
        skip: async item => {
          const previous = all.previous && all.previous.conversations ? all.previous.conversations[item.id] : null;
          const unchanged = Boolean($("opt-incremental").checked && previous && previous.item_update_time && item.update_time && previous.item_update_time === epochIso(item.update_time));
          if (!unchanged || !directory || !previous.files?.length) return false;
          try {
            for (const file of previous.files) {
              const parts = file.split("/");
              if (parts.some(part => !part || part === "." || part === "..")) return false;
              let parent = directory;
              for (const part of parts.slice(0, -1)) parent = await parent.getDirectoryHandle(part);
              const handle = await parent.getFileHandle(parts[parts.length - 1]);
              if ((await handle.getFile()).size === 0) return false;
            }
            return true;
          } catch { return false; }
        },
        fetch: async item => {
          const data = await api(tab.id, { action: "conversation", id: item.id }, 180000);
          if (data && data.chunked) {
            let text = "";
            for (let index = 0; index < data.parts; index += 1) {
              const part = await api(tab.id, { action: "part", job: data.job, index }, 60000);
              text += part.part;
            }
            await send(tab.id, { type: "archive-api", action: "release", job: data.job }).catch(() => {});
            return JSON.parse(text).conversation;
          }
          return data.conversation;
        },
        build: async (conversation, item) => {
          const doc = Convert.buildDoc(conversation, { includeRaw: $("opt-raw").checked, base: "https://chatgpt.com" });
          const name = Convert.baseName(doc);
          const convDir = "assets/" + name;
          if ($("opt-attachments").checked && directory) await saveAssets(tab.id, doc, write, all, convDir);
          const files = [
            { path: name + ".md", content: Convert.markdownDoc(doc) },
            { path: name + ".json", content: JSON.stringify(doc, null, 2) + "\n" }
          ];
          pendingRows.set(item.id, { id: doc.id, title: doc.title, message_count: doc.message_count, create_time: doc.create_time || epochIso(item.create_time), update_time: doc.update_time || epochIso(item.update_time), item_update_time: epochIso(item.update_time), files: files.map(file => file.path) });
          return files;
        },
        write,
        onItem: (item, error, current) => {
          if (error) {
            all.failures.push({ id: item.id, title: item.title, error: String(error.message || error) });
            logLine("失败 " + item.title + "：" + String(error.message || error), "fail");
          } else {
            const row = pendingRows.get(item.id);
            if (row) { all.rows.set(item.id, row); written += 1; logLine("完成 " + row.title + " · " + row.message_count + " 条消息", "ok"); }
            else { skipped += 1; logLine("跳过 " + item.title + "（未更新）", "skip"); }
          }
          $("stat-written").textContent = String(written);
          $("stat-skipped").textContent = String(skipped);
          $("stat-failed").textContent = String(all.failures.length);
        },
        onProgress: (current) => {
          $("stat-done").textContent = current.done + " / " + current.total;
          $("bar").value = current.total ? Math.round(current.done * 100 / current.total) : 0;
          const running = current.current.length ? " · 正在处理 " + current.current.join("、") : "";
          batchStatus("已处理 " + current.done + "/" + current.total + running, "idle");
        }
      });
      const rows = Array.from(all.rows.values());
      const meta = { exported_at: new Date().toISOString(), owner: all.account && all.account.user ? (all.account.user.email || all.account.user.name) : "" };
      const previousMap = all.previous && all.previous.conversations ? all.previous.conversations : {};
      const merged = Object.assign({}, previousMap);
      for (const row of rows) merged[row.id] = { title: row.title, update_time: row.update_time, item_update_time: row.item_update_time, create_time: row.create_time, message_count: row.message_count, files: row.files };
      const indexRows = Object.entries(merged)
        .map(([id, row]) => ({ id, title: row.title || id, message_count: row.message_count || 0, update_time: row.update_time || null, files: row.files || [] }))
        .sort((a, b) => String(b.update_time || "").localeCompare(String(a.update_time || "")));
      await write("index.md", Convert.indexMarkdown(indexRows, meta));
      await write("index.json", JSON.stringify({ schema_version: 2, platform: "ChatGPT", exported_at: meta.exported_at, owner: meta.owner, total: indexRows.length, conversations: indexRows }, null, 2) + "\n");
      const manifest = {
        schema_version: 2,
        platform: "ChatGPT",
        exporter_version: "2.2.0",
        exported_at: meta.exported_at,
        owner: meta.owner,
        conversations: merged,
        last_run: { total: rows.length, written, skipped, failed: result.failed.length, failures: result.failed, cancelled: result.cancelled, selected: chosen.length }
      };
      await write("manifest.json", JSON.stringify(manifest, null, 2) + "\n");
      if (mode === "zip") {
        const zipName = "chatgpt-archive_" + stamp + ".zip";
        batchStatus("正在打包 ZIP（" + all.zipFiles.length + " 个文件）…", "idle");
        const blob = Core.zip(all.zipFiles.map(file => ({ name: file.name, content: file.content })));
        await downloadBlob(blob, zipName, true);
        batchStatus("已下载 " + zipName + " · " + rows.length + " 条对话 · 失败 " + result.failed.length + " 条", result.failed.length ? "warning" : "success");
      } else {
        const target = directory && directory.name ? directory.name : "所选文件夹";
        batchStatus((result.cancelled ? "已取消。已导出 " : "导出完成：") + rows.length + " 条对话写入「" + target + "」· 跳过 " + result.skipped + " · 失败 " + result.failed.length + " · 存档共 " + indexRows.length + " 条", result.failed.length || result.cancelled ? "warning" : "success");
      }
      if (result.failed.length) {
        logLine("—— 失败清单 ——", "fail");
        result.failed.forEach(item => logLine(String(item.title) + "：" + item.error, "fail"));
      }
    } catch (error) {
      batchStatus("导出中断：" + friendly(error), "error");
      logLine("导出中断：" + friendly(error), "fail");
    } finally {
      all.running = false;
      all.signal = null;
      $("cancel-all").hidden = true;
      $("scan-all").disabled = false;
      $("export-folder").disabled = $("export-zip").disabled = all.selected.size === 0;
    }
  }

  /* --------------------------------------------------------------- wiring */
  function savePreferences() {
    return chrome.storage.local.set({ exportPreferences: {
      format: $("format").value, auto: $("auto").checked, limit: $("limit").value,
      wordImages: $("word-images").checked,
      scanModeVersion: 1, readMode: $("read-mode").value,
      archived: $("opt-archived").checked, raw: $("opt-raw").checked,
      incremental: $("opt-incremental").checked, attachments: $("opt-attachments").checked,
      allLimit: $("limit-all").value
    } });
  }
  function bindEvents() {
    $("tab-single").addEventListener("click", () => activateTab("single"));
    $("tab-all").addEventListener("click", () => activateTab("all"));
    $("scan").addEventListener("click", scanSingle);
    $("cancel").addEventListener("click", () => {
      state.single.cancel = true;
      state.single.imageController?.abort();
      if (state.single.imageJob && state.tab) chrome.tabs.sendMessage(state.tab.id, { type: "archive-image", action: "cancel", job: state.single.imageJob }).catch(() => {});
      if (state.tab) chrome.tabs.sendMessage(state.tab.id, { type: "cancel-export", job: state.single.job }).catch(() => {});
      setStatus("status-box", state.single.saving ? "正在取消Word导出…" : "正在取消扫描…", "idle");
    });
    $("save-folder").addEventListener("click", () => saveSingle("folder"));
    $("save-file").addEventListener("click", () => saveSingle("file"));
    $("focus-source").addEventListener("click", async () => {
      if (!state.tab) return setStatus("status-box", "没有可返回的 ChatGPT 标签页。", "warning");
      try { await chrome.tabs.update(state.tab.id, { active: true }); }
      catch (error) { setStatus("status-box", friendly(error), "error"); }
    });
    for (const id of ["format", "auto", "limit", "read-mode", "word-images"]) $(id).addEventListener("change", () => {
      savePreferences();
      updateSingle();
    });
    for (const id of ["opt-archived", "opt-raw", "opt-incremental", "opt-attachments", "limit-all"]) $(id).addEventListener("change", () => {
      savePreferences();
    });
    $("refresh-account").addEventListener("click", () => refreshAccount(true));
    $("scan-all").addEventListener("click", scanAccount);
    $("export-folder").addEventListener("click", () => exportAll("folder"));
    $("export-zip").addEventListener("click", () => exportAll("zip"));
    $("cancel-all").addEventListener("click", () => {
      if (state.all.signal) state.all.signal.cancelled = true;
      batchStatus("正在取消，已完成的文件会保留…", "warning");
    });
    chrome.runtime.onMessage.addListener((message, sender) => {
      if (state.single.busy && message && message.type === "export-progress" && message.job === state.single.job && sender.tab && state.tab && sender.tab.id === state.tab.id) {
        setStatus("status-box", message.message, "idle");
        $("count").textContent = message.count + " 条消息";
      }
    });
    chrome.tabs.onUpdated.addListener((tabId, info) => {
      if (info.status === "loading") injectedTabs.delete(tabId);
    });
    chrome.tabs.onRemoved.addListener(tabId => injectedTabs.delete(tabId));
  }

  /* ------------------------------------------------------------------ init */
  async function init() {
    bindListControls();
    bindEvents();
    const { exportPreferences: prefs } = await chrome.storage.local.get("exportPreferences");
    if (prefs) {
      if (FORMAT_HINTS[prefs.format]) $("format").value = prefs.format;
      if (typeof prefs.wordImages === "boolean") $("word-images").checked = prefs.wordImages;
      if (typeof prefs.auto === "boolean") $("auto").checked = prefs.auto;
      // v2.1 defaults to automatic completion; old short limits must not silently truncate new scans.
      if (prefs.scanModeVersion === 1 && ["0", "30000", "120000", "180000"].includes(prefs.limit)) $("limit").value = prefs.limit;
      if (["auto", "dom"].includes(prefs.readMode)) $("read-mode").value = prefs.readMode;
      if (typeof prefs.archived === "boolean") $("opt-archived").checked = prefs.archived;
      if (typeof prefs.raw === "boolean") $("opt-raw").checked = prefs.raw;
      if (typeof prefs.incremental === "boolean") $("opt-incremental").checked = prefs.incremental;
      if (typeof prefs.attachments === "boolean") $("opt-attachments").checked = prefs.attachments;
      if (["0", "5", "20", "50"].includes(prefs.allLimit)) $("limit-all").value = prefs.allLimit;
    }
    updateSingle();
    try {
      const tab = await resolveTab();
      if (!tab) throw new Error("请在 ChatGPT 对话标签页点击扩展图标，或先打开 chatgpt.com。");
      state.tab = tab;
      state.tabId = tab.id;
      $("source-title").textContent = tab.title || "ChatGPT 当前对话";
      setStatus("status-box", "已连接原对话。点击「读取当前对话」开始扫描。", "idle");
    } catch (error) {
      $("source-title").textContent = "尚未连接对话";
      setStatus("status-box", friendly(error), "error");
    }
    updateSingle();
  }

  init();
})();
