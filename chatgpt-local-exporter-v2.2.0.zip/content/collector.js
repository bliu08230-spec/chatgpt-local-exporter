(() => {
  "use strict";
  if (globalThis.__chatExportCollector?.version === "2.2.0") return;
  globalThis.__chatExportCollector?.dispose?.();
  const collectorInstance = { version: "2.2.0" };
  globalThis.__chatExportCollector = collectorInstance;
  const core = globalThis.ChatExportCore;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const compact = s => String(s || "").replace(/\s+/g, " ").trim();
  let running = null;
  function hash(s) {
    let a = 2166136261, b = 5381;
    for (let i = 0; i < s.length; i++) { a = Math.imul(a ^ s.charCodeAt(i), 16777619); b = Math.imul(b, 33) ^ s.charCodeAt(i); }
    return (a >>> 0).toString(36) + (b >>> 0).toString(36);
  }
  function nodes() {
    const scopes = Array.from(new Set([document.querySelector("main"), document.querySelector('[role="main"]'), document.getElementById("thread"), document.body].filter(Boolean)));
    const forbidden = n => n.closest('nav,aside,header,footer,[role="navigation"],[contenteditable="true"],form');
    const leaf = list => list.filter(n => !list.some(o => n !== o && n.contains(o)));
    for (const scope of scopes) {
      const explicit = Array.from(scope.querySelectorAll("[data-message-author-role]")).filter(n => !forbidden(n) && !n.parentElement?.closest("[data-message-author-role]"));
      if (explicit.length) return { nodes: explicit, guessed: false, selector: "data-message-author-role" };
      const turns = leaf(Array.from(scope.querySelectorAll('[data-testid^="conversation-turn"],[id^="conversation-turn"],[data-turn="user"],[data-turn="assistant"]')).filter(n => !forbidden(n)));
      if (turns.length) return { nodes: turns, guessed: true, selector: "conversation-turn/data-turn" };
    }
    for (const scope of scopes) {
      const messages = leaf(Array.from(scope.querySelectorAll("[data-message-id]")).filter(n => !forbidden(n)));
      if (messages.length) return { nodes: messages, guessed: true, selector: "data-message-id" };
      const regions = leaf(Array.from(scope.querySelectorAll('article[aria-roledescription],article[data-turn-id],[role="article"][data-turn-id]')).filter(n => !forbidden(n)));
      if (regions.length) return { nodes: regions, guessed: true, selector: "article" };
    }
    return { nodes: [], guessed: true, selector: "none" };
  }
  function title() {
    const current = document.querySelector('nav a[aria-current="page"],aside a[aria-current="page"]');
    return compact(current?.textContent || document.title.replace(/\s*[-|｜]\s*ChatGPT\s*$/i, "") || "ChatGPT对话");
  }
  function scroller() {
    for (let n = nodes().nodes[0]?.parentElement; n && n !== document.body; n = n.parentElement) {
      if (/(auto|scroll)/.test(getComputedStyle(n).overflowY) && n.scrollHeight > n.clientHeight + 5) return n;
    }
    return document.scrollingElement || document.documentElement;
  }
  function snapshot(node, index, guessed) {
    const turn = node.closest('[data-testid^="conversation-turn"],[id^="conversation-turn"],[data-turn]') || node;
    const match = ((turn.getAttribute("data-testid") || "") + " " + turn.id).match(/conversation-turn-(\d+)/);
    const directRole = node.getAttribute("data-message-author-role") || turn.getAttribute("data-turn");
    const role = ["user", "assistant", "system", "tool"].includes(directRole) ? directRole : ((match ? Number(match[1]) : index) % 2 ? "assistant" : "user");
    const text = core.plain(node), md = core.markdown(node, location.href);
    const id = node.getAttribute("data-message-id") || node.getAttribute("data-turn-id") || node.id || null;
    const key = id || (match ? "turn-" + match[1] + "-" + role : "content-" + hash(role + text));
    const images = Array.from(node.querySelectorAll("img")).map(img => ({ alt: img.alt || "", url: core.safeUrl(img.currentSrc || img.src, location.href), saved_locally: false })).filter(x => x.url);
    let contentParts;
    if (images.length) {
      const clone = node.cloneNode(true);
      let imageIndex = 0;
      clone.querySelectorAll("img").forEach(img => {
        const url = core.safeUrl(img.currentSrc || img.src, location.href);
        img.replaceWith(url ? "\uE100IMG" + imageIndex++ + "\uE101" : "");
      });
      const chunks = core.plain(clone).split(/(\uE100IMG\d+\uE101)/);
      contentParts = chunks.filter(Boolean).map(text => {
        const match = text.match(/^\uE100IMG(\d+)\uE101$/);
        return match ? { type: "image", index: Number(match[1]) } : { type: "text", text };
      });
    }
    const attachments = Array.from(node.querySelectorAll('a[download],a[href*="/files/"],a[href*="/backend-api/"],a[href*="attachment"]')).map(a => ({ name: compact(a.textContent || a.getAttribute("download")), url: core.safeUrl(a.href, location.href), saved_locally: false })).filter(a => a.url);
    return { key, message_id: id, turn_index: match ? Number(match[1]) : null, role, role_inferred: guessed, text, markdown: md, html: core.htmlFragment(node, location.href), images, attachments, ...(contentParts ? { content_parts: contentParts } : {}) };
  }
  async function collect(job, options) {
    if (running) throw new Error("当前页面已有导出任务，请等待完成或先取消。");
    const token = { id: job, cancelled: false };
    running = token;
    const initialUrl = location.href, started = performance.now();
    let container = scroller(), originalTop = container.scrollTop;
    const saved = new Map(), order = [];
    let steps = 0, reachedTop = false, reachedBottom = false, timedOut = false, roleInferred = false, stalled = false;
    function check() {
      if (token.cancelled) throw new Error("已取消扫描，未保存文件。");
      if (globalThis.__chatExportCollector !== collectorInstance) throw new Error("采集器已更新，请重新读取。");
      if (location.href !== initialUrl) throw new Error("扫描期间对话页面发生切换，请重新导出。");
      if (document.querySelector('button[data-testid="stop-button"],button[aria-label="Stop generating"]')) throw new Error("ChatGPT 正在生成回答，请等待生成结束后导出。");
    }
    function report(message) {
      try { chrome.runtime.sendMessage({ type: "export-progress", job, message, count: saved.size, steps }).catch(() => {}); } catch {}
    }
    function capture(direction) {
      check();
      const found = nodes(); roleInferred ||= found.guessed;
      const batch = found.nodes.map((n, i) => snapshot(n, i, found.guessed)).filter(m => m.text || m.markdown);
      const keys = batch.map(m => m.key);
      if (direction === "up" && keys.length && !keys.some(k => saved.has(k))) order.unshift(...keys);
      else keys.forEach((key, i) => {
        if (order.includes(key)) return;
        const next = keys.slice(i + 1).find(k => order.includes(k));
        if (next) order.splice(order.indexOf(next), 0, key); else order.push(key);
      });
      batch.forEach(m => saved.set(m.key, m));
      return hash(keys.join("|") + ":" + saved.size + ":" + container.scrollHeight);
    }
    async function move(target, direction) {
      check(); container.scrollTop = target; await sleep(520); steps++;
      const signature = capture(direction);
      report((direction === "up" ? "正在回溯早期消息" : "正在逐段收集消息") + "，已读取 " + saved.size + " 条");
      return signature;
    }
    try {
      capture("initial");
      // Page may still be hydrating after a new tab or navigation.
      for (let i = 0; !saved.size && i < 8; i++) { await sleep(350); capture("initial"); }
      if (!saved.size) throw new Error("网页消息结构未识别。请刷新原 ChatGPT 对话后重试；若仍失败，可在「全部对话」列表勾选这条导出。");
      container = scroller(); originalTop = container.scrollTop;
      report("已读取当前页面，开始检查历史内容");
      if (options.autoLoad !== false) {
        const maxMs = Number(options.maxMs);
        const limit = maxMs > 0 ? Math.max(5000, Math.min(maxMs, 180000)) : Infinity;
        const expired = () => performance.now() - started > limit;
        let previous = "", stable = 0, noProgress = 0;
        while (!expired()) {
          const previousTop = container.scrollTop;
          const sig = await move(Math.max(0, container.scrollTop - Math.max(320, container.clientHeight * 0.8)), "up");
          noProgress = sig === previous && Math.abs(container.scrollTop - previousTop) < 2 ? noProgress + 1 : 0;
          stable = container.scrollTop <= 2 && sig === previous ? stable + 1 : 0; previous = sig;
          if (stable >= 4) { reachedTop = true; break; }
          if (noProgress >= 10) { stalled = true; break; }
        }
        previous = ""; stable = 0; noProgress = 0;
        while (!expired()) {
          const previousTop = container.scrollTop;
          const sig = await move(Math.min(container.scrollHeight, container.scrollTop + Math.max(320, container.clientHeight * 0.8)), "down");
          noProgress = sig === previous && Math.abs(container.scrollTop - previousTop) < 2 ? noProgress + 1 : 0;
          const bottom = container.scrollTop + container.clientHeight >= container.scrollHeight - 4;
          stable = bottom && sig === previous ? stable + 1 : 0; previous = sig;
          if (stable >= 3) { reachedBottom = true; break; }
          if (noProgress >= 10) { stalled = true; break; }
        }
        timedOut = expired() && !(reachedTop && reachedBottom);
      }
      check();
      let messages = Array.from(new Set(order)).map(k => saved.get(k)).filter(Boolean);
      if (messages.every(m => Number.isFinite(m.turn_index))) messages.sort((a, b) => a.turn_index - b.turn_index);
      messages = messages.map((m, i) => { const { key, ...rest } = m; return { index: i + 1, ...rest }; });
      const warnings = ["DOM 扫描记录本次可加载的当前回答分支，无法证明服务端历史已全部覆盖。", "图片和附件保留链接，不下载原文件；链接可能过期。"];
      if (timedOut) warnings.push("达到网页扫描等待上限，建议选择自动完成或优先读取会话数据后重试；等待上限不是聊天记录的日期范围。");
      if (stalled) warnings.push("网页滚动没有继续推进，已停止等待；未确认全部内容。可尝试自动读取会话数据。");
      if (options.autoLoad === false) warnings.push("未开启历史加载，仅导出当前已挂载到网页的消息。");
      if (roleInferred) warnings.push("部分消息角色按页面顺序推断，请核对角色标记。");
      if (messages.some(m => !m.message_id && m.turn_index === null)) warnings.push("部分消息缺少稳定 ID，重复文本存在合并风险。");
      const data = { schema_version: 1, title: title(), platform: "ChatGPT", source_url: initialUrl, exported_at: new Date().toISOString(), message_count: messages.length, messages,
        scan: { method: "visible-dom-accumulation", selector: nodes().selector, scope: "current-conversation-current-branch", auto_load: options.autoLoad !== false, reached_top: reachedTop, reached_bottom: reachedBottom, timed_out: timedOut, stalled, steps, duration_ms: Math.round(performance.now() - started), authoritative_complete: false, warnings } };
      report("扫描完成：" + messages.length + " 条消息");
      return data;
    } finally { if (location.href === initialUrl) container.scrollTop = originalTop; running = null; }
  }
  const listener = (message, sender, sendResponse) => {
    if (message?.type === "cancel-export") { if (running?.id === message.job) running.cancelled = true; sendResponse({ ok: true }); return; }
    if (message?.type !== "collect-conversation") return;
    collect(message.job, message.options || {}).then(data => sendResponse({ ok: true, data })).catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  };
  collectorInstance.dispose = () => { if (running) running.cancelled = true; chrome.runtime.onMessage.removeListener(listener); };
  chrome.runtime.onMessage.addListener(listener);
})();
