(() => {
  "use strict";
  if (globalThis.__chatgptArchiveApi) return;
  globalThis.__chatgptArchiveApi = true;

  const API_VERSION = 2;
  const DEVICE_KEY = "chatgpt-archive-device-id";
  const SESSION_TTL = 10 * 60 * 1000;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const state = { token: null, tokenAt: 0, user: null, plan: null, accountId: null };

  const isChatGPT = /(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/i.test(location.hostname);

  function lang() {
    return document.documentElement?.lang || navigator.language || "zh-CN";
  }
  function deviceId() {
    try {
      let value = localStorage.getItem(DEVICE_KEY);
      if (!value) {
        value = (crypto.randomUUID && crypto.randomUUID()) || String(Date.now()) + Math.random().toString(36).slice(2);
        localStorage.setItem(DEVICE_KEY, value);
      }
      return value;
    } catch {
      return "00000000-0000-4000-8000-000000000000";
    }
  }
  async function session(force) {
    if (!force && state.token && Date.now() - state.tokenAt < SESSION_TTL) return state;
    const response = await fetch("/api/auth/session", {
      credentials: "include",
      cache: "no-store",
      headers: { accept: "application/json", "oai-language": lang() }
    });
    if (!response.ok) throw new Error("读取登录状态失败（HTTP " + response.status + "）");
    const data = await response.json().catch(() => ({}));
    state.token = data?.accessToken || null;
    state.tokenAt = Date.now();
    if (data?.user) state.user = { name: data.user.name || null, email: data.user.email || null, image: data.user.image || null };
    state.plan = data?.account?.planType || null;
    state.accountId = data?.account?.id || null;
    return state;
  }
  async function request(path, options) {
    const opts = options || {};
    const attempt = opts.attempt || 0;
    await session(attempt > 0);
    const headers = { accept: "application/json", "oai-language": lang(), "oai-device-id": deviceId() };
    if (state.token) headers.authorization = "Bearer " + state.token;
    // Team / Enterprise workspaces need the account id the web client itself sends.
    if (state.accountId) headers["chatgpt-account-id"] = state.accountId;
    if (opts.method && opts.method !== "GET") headers["content-type"] = "application/json";
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeout || 90000);
    let response;
    try {
      response = await fetch(path, {
        method: opts.method || "GET",
        credentials: "include",
        cache: "no-store",
        headers,
        body: opts.body,
        signal: controller.signal
      });
    } catch (error) {
      clearTimeout(timer);
      if (attempt < 2) {
        await sleep(700 * (attempt + 1));
        return request(path, Object.assign({}, opts, { attempt: attempt + 1 }));
      }
      throw new Error("请求失败：" + (error?.name === "AbortError" ? "超时" : String(error?.message || error)));
    }
    clearTimeout(timer);
    if (response.status === 401 && attempt < 1) {
      state.token = null;
      await sleep(400);
      return request(path, Object.assign({}, opts, { attempt: attempt + 1 }));
    }
    if ((response.status === 429 || response.status >= 500) && attempt < 2) {
      const retryAfter = Number(response.headers.get("retry-after"));
      const wait = Number.isFinite(retryAfter) && retryAfter > 0 ? Math.min(retryAfter * 1000, 30000) : 1500 * (attempt + 1);
      await sleep(wait);
      return request(path, Object.assign({}, opts, { attempt: attempt + 1 }));
    }
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      let message = "HTTP " + response.status;
      if (response.status === 401) message = "登录状态失效，请刷新该 ChatGPT 标签页后重试";
      if (response.status === 403) message = "服务端拒绝访问（HTTP 403），请确认该标签页已登录";
      if (response.status === 404) message = "接口不存在（HTTP 404），ChatGPT 可能已改版";
      throw new Error(message + (detail ? "：" + detail.replace(/\s+/g, " ").slice(0, 200) : ""));
    }
    return response;
  }
  const jsonOf = async (path, options) => (await request(path, options)).json();

  function normalizeItem(item) {
    return {
      id: item.id,
      title: item.title || "未命名对话",
      create_time: item.create_time || null,
      update_time: item.update_time || null,
      archived: Boolean(item.is_archived),
      project_id: item.conversation_template_id || item.gizmo_id || null
    };
  }
  async function listConversations(options) {
    const opts = options || {};
    if (!isChatGPT) throw new Error("请在 ChatGPT 页面中运行");
    await session(false);
    if (!state.token) throw new Error("未检测到 ChatGPT 登录状态，请先在该标签页登录");
    const archived = opts.archived ? "true" : "false";
    const pageSize = Math.max(1, Math.min(Number(opts.pageSize) || 100, 100));
    const items = [];
    const seen = new Set();
    let offset = 0;
    while (true) {
      const data = await jsonOf("/backend-api/conversations?offset=" + offset + "&limit=" + pageSize + "&order=updated&is_archived=" + archived);
      if (!Array.isArray(data?.items)) throw new Error("对话列表格式已变化，未返回 items；本次未确认列表完整。");
      const page = data.items;
      if (!page.length) break;
      let fresh = 0;
      for (const item of page) {
        if (!item || !item.id || seen.has(item.id)) continue;
        seen.add(item.id);
        items.push(normalizeItem(item));
        fresh += 1;
      }
      const total = data.total == null || data.total === "" ? NaN : Number(data.total);
      offset += page.length;
      // The service may clamp `limit` below the requested pageSize, so stop on
      // "no progress" or a known total rather than on page length alone.
      if (fresh === 0) {
        if (Number.isFinite(total) && items.length < total) throw new Error("服务端重复返回同一页，尚有对话未读取，请稍后重试。");
        break;
      }
      if (Number.isFinite(total) && offset >= total) break;
    }
    return { items, total: items.length, archived: Boolean(opts.archived) };
  }
  async function conversation(id) {
    if (!id) throw new Error("缺少会话 ID");
    const data = await jsonOf("/backend-api/conversation/" + encodeURIComponent(id));
    if (!data || typeof data !== "object" || (!data.mapping && !data.conversation_id)) throw new Error("会话内容为空或格式已变化");
    return data;
  }
  async function toBase64(response) {
    const bytes = new Uint8Array(await response.arrayBuffer());
    let binary = "";
    const chunk = 0x8000;
    for (let index = 0; index < bytes.length; index += chunk) binary += String.fromCharCode.apply(null, bytes.subarray(index, index + chunk));
    return btoa(binary);
  }
  async function downloadFile(fileId) {
    if (!fileId) throw new Error("缺少文件 ID");
    const info = await jsonOf("/backend-api/files/" + encodeURIComponent(fileId) + "/download");
    const url = info?.download_url || info?.url;
    if (!url) throw new Error("没有可用的下载地址");
    const absolute = new URL(url, location.origin).href;
    const response = await fetch(absolute, { credentials: absolute.startsWith(location.origin) ? "include" : "omit" });
    if (!response.ok) throw new Error("下载失败（HTTP " + response.status + "）");
    const size = Number(response.headers.get("content-length")) || 0;
    if (size > 24 * 1024 * 1024) throw new Error("文件过大，已跳过（" + Math.round(size / 1048576) + "MB）");
    return { base64: await toBase64(response), mime: response.headers.get("content-type") || "" };
  }
  // Large conversations may exceed the runtime message limit, so big payloads
  // are parked here and streamed back in slices.
  const buffer = new Map();
  const BUFFER_LIMIT = 6;
  const CHUNK = 2 * 1024 * 1024;
  function park(text) {
    const job = "job-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
    const parts = [];
    for (let index = 0; index < text.length; index += CHUNK) parts.push(text.slice(index, index + CHUNK));
    buffer.set(job, parts);
    while (buffer.size > BUFFER_LIMIT) buffer.delete(buffer.keys().next().value);
    return { chunked: true, job, parts: parts.length, size: text.length };
  }
  async function status() {
    await session(true);
    return {
      api_version: API_VERSION,
      logged_in: Boolean(state.token),
      user: state.user,
      plan: state.plan,
      origin: location.origin,
      url: location.href,
      title: document.title
    };
  }

  async function handle(message) {
    switch (message.action) {
      case "status": return status();
      case "list": return listConversations({ archived: message.archived, pageSize: message.pageSize });
      case "conversation": {
        const data = await conversation(message.id);
        const text = JSON.stringify({ conversation: data });
        // Chrome caps a single runtime message at ~64 MB but the SW->tab hop is
        // smaller in practice; 8 MB of JSON is the safe split point here.
        return text.length > 8 * 1024 * 1024 ? park(text) : { conversation: data };
      }
      case "part": {
        const parts = buffer.get(message.job);
        if (!parts) throw new Error("会话内容已过期，请重新导出该对话");
        const value = parts[message.index];
        if (typeof value !== "string") throw new Error("分片序号越界");
        return { index: message.index, part: value };
      }
      case "release": buffer.delete(message.job); return { released: true };
      case "download": return downloadFile(message.fileId);
      default: throw new Error("未知操作：" + message.action);
    }
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== "archive-api") return undefined;
    handle(message)
      .then(data => sendResponse({ ok: true, data }))
      .catch(error => sendResponse({ ok: false, error: String((error && error.message) || error) }));
    return true;
  });
})();
