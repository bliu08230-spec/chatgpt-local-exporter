(() => {
  "use strict";
  // Independent from the proven conversation reader: this script runs only on Word export.
  if (globalThis.__chatExportImages) return;
  globalThis.__chatExportImages = true;
  const MAX_BYTES = 32 * 1024 * 1024, CHUNK = 512 * 1024;
  const buffers = new Map(), controllers = new Map();
  function allowed(value) {
    try {
      const u = new URL(value, location.origin);
      return (u.origin === location.origin && ["https:", "blob:"].includes(u.protocol)) ||
        /^data:image\/(?:png|jpeg|gif|webp);base64,/i.test(value) ||
        (u.protocol === "https:" && (u.hostname === "oaiusercontent.com" || u.hostname.endsWith(".oaiusercontent.com")));
    } catch { return false; }
  }
  const b64 = bytes => {
    let result = "";
    for (let i = 0; i < bytes.length; i += 32768) result += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return btoa(result);
  };
  async function read(response) {
    if (!response.ok) throw new Error("图片下载失败（HTTP " + response.status + "）");
    if (Number(response.headers.get("content-length")) > MAX_BYTES) throw new Error("单图超过32MB，已跳过以保护浏览器内存");
    const reader = response.body.getReader(), chunks = [];
    let length = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        length += value.length;
        if (length > MAX_BYTES) throw new Error("单图超过32MB，已跳过以保护浏览器内存");
        chunks.push(value);
      }
    } catch (error) { await reader.cancel().catch(() => {}); throw error; }
    const bytes = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
    return { bytes, mime: response.headers.get("content-type") || "" };
  }
  function domUrls(message) {
    const out = [], id = message.asset?.file_id;
    for (const img of document.querySelectorAll("img")) {
      const url = img.currentSrc || img.src;
      if (id && /^[A-Za-z0-9_-]+$/.test(id) && new RegExp("(?:^|[^A-Za-z0-9_-])" + id + "(?:$|[^A-Za-z0-9_-])").test(url)) out.push(url);
    }
    if (message.messageId) {
      const node = Array.from(document.querySelectorAll("[data-message-id],[data-turn-id],[id]")).find(n => [n.getAttribute("data-message-id"), n.getAttribute("data-turn-id"), n.id].includes(message.messageId));
      const imgs = node ? Array.from(node.querySelectorAll("img")) : [];
      if (imgs.length === message.count && imgs[message.index]) out.push(imgs[message.index].currentSrc || imgs[message.index].src);
    }
    return out;
  }
  async function start(message) {
    const controller = new AbortController(), job = message.job;
    controllers.set(job, controller);
    const timer = setTimeout(() => controller.abort(), 45000);
    const candidates = [], errors = [];
    let originalUrl = null;
    try {
      const id = message.asset?.file_id;
      if (id && !message.previewOnly) {
        try {
          const response = await fetch("/api/auth/session", { credentials: "include", cache: "no-store", signal: controller.signal });
          if (!response.ok) throw new Error("登录状态HTTP " + response.status);
          const session = await response.json(), headers = { accept: "application/json", "oai-language": document.documentElement.lang || navigator.language };
          if (session.accessToken) headers.authorization = "Bearer " + session.accessToken;
          if (session.account?.id) headers["chatgpt-account-id"] = session.account.id;
          try { const device = localStorage.getItem("chatgpt-archive-device-id"); if (device) headers["oai-device-id"] = device; } catch {}
          for (const path of ["/backend-api/files/" + encodeURIComponent(id) + "/download", "/backend-api/files/download/" + encodeURIComponent(id)]) {
            const meta = await fetch(path, { credentials: "include", headers, signal: controller.signal });
            if (meta.status === 404) continue;
            if (!meta.ok) throw new Error("原图地址HTTP " + meta.status);
            const info = await meta.json();
            if (info.download_url || info.url) { originalUrl = info.download_url || info.url; candidates.push(originalUrl); break; }
          }
          if (!originalUrl) throw new Error("原图下载地址不可用");
        } catch (error) { errors.push(error.message); }
      }
      if (message.asset?.url && !message.previewOnly) candidates.push(message.asset.url);
      candidates.push(...domUrls(message));
      for (const candidate of new Set(candidates)) {
        if (!allowed(candidate)) { errors.push("图片地址不在允许的ChatGPT文件域名内"); continue; }
        try {
          const url = new URL(candidate, location.origin);
          const data = await read(await fetch(url.href, { credentials: url.origin === location.origin ? "include" : "omit", signal: controller.signal }));
          if (controller.signal.aborted) throw new Error("图片读取已取消");
          if (!data.bytes.length) throw new Error("图片为空");
          buffers.set(job, data);
          setTimeout(() => buffers.delete(job), 120000);
          return { job, size: data.bytes.length, parts: Math.ceil(data.bytes.length / CHUNK), mime: data.mime, preview: candidate !== originalUrl };
        } catch (error) {
          errors.push(error.message);
          if (controller.signal.aborted) throw new Error("图片读取已取消或超过45秒");
          // The extension page has explicit file-CDN host permission, so it can
          // retry CORS-blocked signed URLs without forwarding any session token.
          if (error instanceof TypeError && new URL(candidate, location.origin).hostname.endsWith(".oaiusercontent.com")) return { retry_url: candidate, preview: candidate !== originalUrl };
        }
      }
      throw new Error(errors.join("；") || "未找到仍可访问的图片地址");
    } finally { clearTimeout(timer); controllers.delete(job); }
  }
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message?.type !== "archive-image") return;
    if (message.action === "cancel") {
      controllers.get(message.job)?.abort(); buffers.delete(message.job); reply({ ok: true }); return;
    }
    if (message.action === "release") { buffers.delete(message.job); reply({ ok: true }); return; }
    if (message.action === "part") {
      const data = buffers.get(message.job), index = Number(message.index);
      if (!data || !Number.isInteger(index) || index < 0 || index * CHUNK >= data.bytes.length) reply({ ok: false, error: "图片分片已失效" });
      else reply({ ok: true, data: { base64: b64(data.bytes.subarray(index * CHUNK, (index + 1) * CHUNK)) } });
      return;
    }
    if (message.action !== "start") return;
    start(message).then(data => reply({ ok: true, data })).catch(error => reply({ ok: false, error: String(error.message || error) }));
    return true;
  });
})();
