"use strict";
const PANEL_PAGE = "popup/popup.html";
chrome.action.onClicked.addListener(async tab => {
  const panelUrl = chrome.runtime.getURL(PANEL_PAGE) + (tab && tab.id ? "?tabId=" + tab.id : "");
  try {
    const open = await chrome.tabs.query({ url: chrome.runtime.getURL(PANEL_PAGE) + "*" });
    if (open && open.length) {
      await chrome.tabs.update(open[0].id, { url: panelUrl, active: true });
      if (open[0].windowId) await chrome.windows.update(open[0].windowId, { focused: true });
      return;
    }
  } catch { /* reuse is best-effort; a new tab always works */ }
  await chrome.tabs.create({ url: panelUrl });
});